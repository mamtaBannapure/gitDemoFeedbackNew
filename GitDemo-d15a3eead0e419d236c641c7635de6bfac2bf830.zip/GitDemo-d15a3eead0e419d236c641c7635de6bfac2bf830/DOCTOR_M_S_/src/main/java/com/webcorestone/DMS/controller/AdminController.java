package com.webcorestone.DMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.AddressDetails;
import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.model.LoginDetails;
import com.webcorestone.DMS.serviceI.AdminServiceI;
import com.webcorestone.DMS.serviceI.EmployeeServiceI;
@CrossOrigin("*")
@RestController
@RequestMapping("/admin")
public class AdminController {

	@Autowired
	AdminServiceI adminService;

	@Autowired
	ObjectMapper obj;
	@Autowired EmployeeServiceI es;
	
	
	
	
@PostMapping("/add")
public String saveAdminDetailes(@RequestBody AdminDetails admin)
{
	
	System.out.println("HELLO");
	int status=adminService.saveAdminDetailes(admin);
	return "registerd Successfully";
	
}
@GetMapping("/getAll")
public List<AdminDetails> getAllAdminDetailes() throws JsonProcessingException
{
//	List<EmployeeDetails>list1=es.getAllEmp();
		 List<AdminDetails> list=adminService.getAllAdminData(); 
		
		 String status=obj.writeValueAsString(list);
		 
	return list;
	
}
@GetMapping("/getOne/{adminId}")
public String getSingleAdminDetailes(@PathVariable String adminId) throws JsonProcessingException
{
	
	int id=Integer.parseInt(adminId);
	System.out.println(id);
	List<AdminDetails> data=adminService.getOneAdminData(id);
	String dat=obj.writeValueAsString(data);
	return dat;
	
}
@DeleteMapping("/delete/{adminId}")
public String deleteAdmin(@PathVariable String adminId) throws JsonProcessingException
{
	int id=Integer.parseInt(adminId);
	adminService.deleteAdminData(id);
	List<AdminDetails> data=adminService.getOneAdminData(id);
	String dat=obj.writeValueAsString(data);
	return dat;
	
	
}
@GetMapping("/edit/{adminId}")
public String editAdmin(@PathVariable String adminId) throws JsonProcessingException
{
	int id=Integer.parseInt(adminId);
	AdminDetails add=adminService.editAdminData(id);
	String dat=obj.writeValueAsString(add);
	return dat;
	
}
@PutMapping("/update")
public String updateAdminDetailes(@RequestBody AdminDetails admin)
{
	adminService.updateAdminData(admin);
	
	return "record Updated Successfully";
	
}
@PostMapping("/addEmployee")
public String addEmployeeDetailes(@RequestBody EmployeeDetails employeeDetailes)
{
	
	return null;
	
	}
@GetMapping("/getEmp")
public List<EmployeeDetails> getEmpdata()
{
List<EmployeeDetails> ed=es.getAllEmp();
	return ed;
}
}
