package com.webcorestone.DMS.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties.Admin;
import org.springframework.stereotype.Service;

import com.webcorestone.DMS.daoI.AdminDaoI;
import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.serviceI.AdminServiceI;


@Service
public class AdminServiceImpl implements AdminServiceI
{
	@Autowired
	AdminDaoI addao;
	
	@Override
	public int saveAdminDetailes(AdminDetails admin) {
		addao.save(admin);
		return 0;
	}

	@Override
	public List<AdminDetails> getAllAdminData() {
		
		return addao.findAll();
	}

	@Override
	public List<AdminDetails> getOneAdminData(int id) {
		List<AdminDetails> data=addao.findAllByAdminId(id);
		return data;
	}

	@Override
	public int deleteAdminData(int id) {
		addao.deleteById(id);
		return 1;
	}

	@Override
	public AdminDetails editAdminData(int id) {
		AdminDetails adm=addao.findById(id).get();
		return adm;
	}

	@Override
	public int updateAdminData(AdminDetails admin) {
	addao.save(admin);
		return 0;
	}

//	@Override
//	public int saveEmployeeDetailes(EmployeeDetails employee) {
//      addao.save(employee);
//		return 0;
	}
	
	

	


