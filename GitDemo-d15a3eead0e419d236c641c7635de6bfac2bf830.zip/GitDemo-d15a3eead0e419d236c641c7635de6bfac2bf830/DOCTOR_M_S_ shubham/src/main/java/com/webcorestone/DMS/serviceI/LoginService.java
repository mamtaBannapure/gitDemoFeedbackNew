package com.webcorestone.DMS.serviceI;

import com.webcorestone.DMS.model.LoginDetails;

public interface LoginService {

	public LoginDetails loginAdminData(String un,String pw);
	
}
