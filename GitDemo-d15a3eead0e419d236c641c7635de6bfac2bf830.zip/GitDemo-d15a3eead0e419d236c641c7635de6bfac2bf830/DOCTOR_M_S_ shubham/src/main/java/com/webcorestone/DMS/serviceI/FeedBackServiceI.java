package com.webcorestone.DMS.serviceI;

import java.util.List;

import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.FeedbackDetails;

public interface FeedBackServiceI {
	public int saveFeedBack(FeedbackDetails feedback);
	public List<FeedbackDetails> getAllFeedback();
	public List<FeedbackDetails> getOneFeedback(int id);
	public int deleteFeedback(int id);

}
