package com.webcorestone.DMS.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class FeedbackDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int feedbackId;
	private String feedbackMessage;
	
	@JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy")
	private Date feedbackdate;

public FeedbackDetails() {
	// TODO Auto-generated constructor stub
}

	public int getFeedbackId() {
		return feedbackId;
	}



	public void setFeedbackId(int feedbackId) {
		this.feedbackId = feedbackId;
	}



	public String getFeedbackMessage() {
		return feedbackMessage;
	}



	public void setFeedbackMessage(String feedbackMessage) {
		this.feedbackMessage = feedbackMessage;
	}



	public Date getFeedbackdate() {
		return feedbackdate;
	}



	public void setFeedbackdate(Date feedbackdate) {
		this.feedbackdate = feedbackdate;
	}



	@Override
	public String toString() {
		return "FeedbackDetails [feedbackId=" + feedbackId + ", feedbackMessage=" + feedbackMessage + ", feedbackdate="
				+ feedbackdate + "]";
	}

	
}
