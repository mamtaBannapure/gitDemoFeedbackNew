package com.webcorestone.DMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.FeedbackDetails;
import com.webcorestone.DMS.serviceI.AdminServiceI;
import com.webcorestone.DMS.serviceI.EmployeeServiceI;
import com.webcorestone.DMS.serviceI.FeedBackServiceI;

@CrossOrigin("*")
@RestController
@RequestMapping("/feedback")
public class FeedbackController {
	
	@Autowired
	FeedBackServiceI feedbackService;

	@Autowired
	ObjectMapper obj;
	
	
	@PostMapping("/add")
public String saveFeedbackDetailes(@RequestBody FeedbackDetails feedback)
{
	System.out.println(feedback);
	System.out.println("HELLO");
	int status=feedbackService.saveFeedBack(feedback);
	return "feedback Successfully";
	
}
	
@GetMapping("/getAllFeedback")
public List<FeedbackDetails> getAllFeedbackDetailes() throws JsonProcessingException
{
	System.out.println("IN Feedback GET METHORD");
		 List<FeedbackDetails> list=feedbackService.getAllFeedback(); 
		 for(FeedbackDetails f:list)
		 {
			System.out.println(f.getFeedbackId());
			System.out.println(f.getFeedbackMessage());
			System.out.println(f.getFeedbackdate());
		 }
			 String status=obj.writeValueAsString(list);
		return list;
	
}

@GetMapping("/getOne/{feedbackId}")
public String getSingleFeedbackDetaile(@PathVariable String feedbackId) throws JsonProcessingException
{
	
	int id=Integer.parseInt(feedbackId);
	System.out.println(id);
	List<FeedbackDetails> data=feedbackService.getOneFeedback(id);
	String dat=obj.writeValueAsString(data);
	return dat;
	
}

@DeleteMapping("/delete/{feedbackId}")
public String deleteFeedback(@PathVariable String feedbackId) throws JsonProcessingException
{
	System.out.println("in delet controller");
	int id=Integer.parseInt(feedbackId);
feedbackService.deleteFeedback(id);

	List<FeedbackDetails> data=feedbackService.getOneFeedback(id);
	String dat=obj.writeValueAsString(data);
	return dat;
	
	
}
	

}
