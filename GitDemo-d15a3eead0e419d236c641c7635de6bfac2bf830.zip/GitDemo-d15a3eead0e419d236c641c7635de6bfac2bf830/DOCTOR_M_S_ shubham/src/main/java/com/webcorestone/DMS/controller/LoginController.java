package com.webcorestone.DMS.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.webcorestone.DMS.model.AdminDetails;
import com.webcorestone.DMS.model.LoginDetails;
import com.webcorestone.DMS.serviceI.AdminServiceI;
import com.webcorestone.DMS.serviceI.LoginService;
@CrossOrigin("*")
@RestController
@RequestMapping("/login")
public class LoginController {

	@Autowired
	LoginService loginservice;
	@Autowired
	AdminServiceI adminservice;

	@Autowired
	ObjectMapper obj;
	
	
	@PostMapping("/log")
	public LoginDetails loginAdminDetailes(@RequestBody LoginDetails login)
	{
		System.out.println("IN LOGIN CONTROLLER");
		String un=login.getLoginUserName();
		String pw=login.getLoginPassword();
		System.out.println(un);
		System.out.println(pw);
//		String status=login.getStatus();
//		int role=login.getRole();
		
		
		LoginDetails ld=loginservice.loginAdminData(un, pw);
		System.out.println(ld.getLoginId());
		System.out.println(ld.getLoginPassword());
		System.out.println(ld.getLoginUserName());
		System.out.println(ld.getStatus());
		System.out.println(ld.getRole());
		String user=ld.getLoginUserName();
     	return ld;
		
	}

	
	
	
}
