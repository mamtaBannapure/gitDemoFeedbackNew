package com.webcorestone.DMS.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.webcorestone.DMS.daoI.EmployeeDaoI;
import com.webcorestone.DMS.model.EmployeeDetails;
import com.webcorestone.DMS.serviceI.EmployeeServiceI;

@Service
public class EmployeeServiceImpl implements EmployeeServiceI  {

	@Autowired
	EmployeeDaoI employeedao;
	
	@Override
	public List<EmployeeDetails> getAllEmp() {
		return	employeedao.findAll();
		
	}

	@Override
	public int saveEmployee(EmployeeDetails employee) {
		
		employeedao.save(employee);
		return 1;
	}
	
	

}
