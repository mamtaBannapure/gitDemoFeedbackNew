package com.webcorestone.DMS.serviceI;

public interface MedicalStudentServiceI {

}
